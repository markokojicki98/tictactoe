#ifndef _BOARDSPOT_H_
#define _BOARDSPOT_H_
#include <iostream>

using namespace std;


class BoardSpot{
 public:  
  int place;
  int type;
  BoardSpot(){place=1;type=0;}
  BoardSpot(int p, int t);
  BoardSpot(const BoardSpot& bs);
  void setType(int t);
  int getType(){return type;}
};

#endif
