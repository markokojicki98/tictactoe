#include <iostream>
#include "BoardSpot.h"
using namespace std;

BoardSpot::BoardSpot(int p, int t){
  place=p;
  type=t;
}

BoardSpot::BoardSpot(const BoardSpot& bs){
  place=bs.place;
  type=bs.type;
}

void BoardSpot::setType(int t){
  type=t;
}

