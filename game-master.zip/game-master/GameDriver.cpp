#include <iostream>
using namespace std;
#include <cstdlib>
#include "GameBoard.h"
#include "AI.h"

int main(){
  int op;
  cout<<"Enter 1 for easy AI or 2 for medium"<<endl;
  cin>>op;
  cout<<"|1|2|3|"<<endl;
  cout<<"|4|5|6|"<<endl;
  cout<<"|7|8|9|"<<endl;
  cout<<"Enter space number to place x."<<endl;

  GameBoard *board = new GameBoard(9);
  AI opponent;
  int x=0;
  int y=0;
  if(op==1){
  while(x==0)
    { 
        if(y%2==0)
  	  {
	    board->playerMove();	 
	  }
        else
	  {
	    int bs;
	    bs=opponent.MiniMax(board);
	    opponent.MakeMove(board, bs);
	  }
        y++;          
      x = board->winCheck();
      board->display();
  }
}
  if(op==2){
  while(x==0)
    { 
        if(y%2==0)
  	  {
	    board->playerMove();	 
	  }
        else
	  {
	    int bs;
	    bs=opponent.RandomAI(board);
	    opponent.MakeMove(board, bs);
	  }
        y++;          
      x = board->winCheck();
      board->display();
  }
}
if(x==1)
  cout<<"Congratulations! You win!"<<endl;
else
  cout<<"Game over"<<endl;
}
