#include <iostream>
#include "GameBoard.h"
#include "BoardSpot.h"
using namespace std;

class AI {
 private:
  int level;
 public:
  AI();
  AI(int lvl);
  int EasyAI(GameBoard &);
  int RandomAI(GameBoard &);
  int MiniMax(GameBoard &, int d, bool isPlayer);
  int BestMove(GameBoard &);
  void MakeMove(GameBoard &, int);
};

