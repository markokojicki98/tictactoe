#include<iostream>
#include<fstream>
using namespace std;
#ifdef MACOSX
#include<GLUT/glut.h>
#else
#include<GL/glut.h>
#endif
#include<string.h>
#include<math.h>
#include<stdlib.h>
#include<sstream>
#include<cstdlib>
#include"texture.h"
#include"GameBoard.h"
#include"AI.h"

int WIDTH = 500;  // width of the user window
int HEIGHT = 500;  // height of the user window
char programName[] = "proto-ui";
int xTexture, oTexture;
GameBoard UIBoard;
AI ai;
int win = 0;

// button info
bool buttonOneIsPressed = false, overButtonOne = false;
bool buttonTwoIsPressed = false, overButtonTwo = false;
bool buttonThreeIsPressed = false, overButtonThree = false;
bool buttonFourIsPressed = false, overButtonFour = false;
bool buttonFiveIsPressed = false, overButtonFive = false;
bool buttonSixIsPressed = false, overButtonSix = false;
bool buttonSevenIsPressed = false, overButtonSeven = false;
bool buttonEightIsPressed = false, overButtonEight = false;
bool buttonNineIsPressed = false, overButtonNine = false;

double buttonOnePos[] = { 100, 100,   100, 100 };  // upper left, width, height
double buttonTwoPos[] = { 200, 100,  100, 100 };
double buttonThreePos[] = { 300, 100,  100, 100 };
double buttonFourPos[] = { 100, 200,  100, 100 };
double buttonFivePos[] = { 200, 200,  100, 100 };
double buttonSixPos[] = { 300, 200,  100, 100 };
double buttonSevenPos[] = { 100, 300,  100, 100 };
double buttonEightPos[] = { 200, 300,  100, 100 };
double buttonNinePos[] = { 300, 300,  100, 100 };
double lineOnePos[] = { 200, 100, 5, 300 };
double lineTwoPos[] = { 300, 100, 5, 300 };
double lineThreePos[] = {100, 200, 300, 5};
double lineFourPos[] = {100, 300, 300, 5};

// the following function draws a rectangle, given
//   the upper left vertex and the width and height
void drawBox(double x, double y, double width, double height)
{
  glBegin(GL_POLYGON);
    glVertex2f(x, y);  // upper left
    glVertex2f(x, y + height);  // lower left
    glVertex2f(x + width, y + height);  // lower right
    glVertex2f(x + width, y);  // upper right
  glEnd();
}
void drawBox(double *pos)
{
  drawBox(pos[0], pos[1], pos[2], pos[3]);
}

// the drawText function draws some text at location x, y
//   note:  the text to be drawn is a C-style string!
void drawText(double x, double y, const char *text)
{
  glRasterPos2f( x, y );
  int length = strlen(text);
  for (int i = 0; i < length; i++)
    glutBitmapCharacter(GLUT_BITMAP_9_BY_15, text[i]);
}

void drawWindow()
{
  // clear the buffer
  glClear(GL_COLOR_BUFFER_BIT);

  // draw the button
  if ( buttonOneIsPressed ) glColor3f(0., 1., 0.);  // make it red
  else if ( overButtonOne ) glColor3f(.75,.75,.75);  // light gray
  else glColor3f(0, 0, 0);  // black
  drawBox(buttonOnePos);

  // draw button two
  if ( buttonTwoIsPressed ) glColor3f(0., 1., 0.);  // make it green
  else if ( overButtonTwo ) glColor3f(.75,.75,.75);  // light gray
  else glColor3f(0, 0, 0);  // black
  drawBox(buttonTwoPos);

  // draw button three
  if ( buttonThreeIsPressed ) glColor3f(0., 1., 0.);  // make it green
  else if ( overButtonThree ) glColor3f(.75,.75,.75);  // light gray
  else glColor3f(0, 0, 0);  // black
  drawBox(buttonThreePos);

  // draw button four
  if ( buttonFourIsPressed ) glColor3f(0., 1., 0.);  // make it green
  else if ( overButtonFour ) glColor3f(.75,.75,.75);  // light gray
  else glColor3f(0, 0, 0);  // black
  drawBox(buttonFourPos);
  
  // draw button five
  if ( buttonFiveIsPressed ) glColor3f(0., 1., 0.);  // make it green
  else if ( overButtonFive ) glColor3f(.75,.75,.75);  // light gray
  else glColor3f(0, 0, 0);  // black
  drawBox(buttonFivePos);

  // draw button six
  if ( buttonSixIsPressed ) glColor3f(0., 1., 0.);  // make it green
  else if ( overButtonSix ) glColor3f(.75,.75,.75);  // light gray
  else glColor3f(0, 0, 0);  // black
  drawBox(buttonSixPos);

  // draw button seven
  if ( buttonSevenIsPressed ) glColor3f(0., 1., 0.);  // make it green
  else if ( overButtonSeven ) glColor3f(.75,.75,.75);  // light gray
  else glColor3f(0, 0, 0);  // black
  drawBox(buttonSevenPos);

  // draw button eight
  if ( buttonEightIsPressed ) glColor3f(0., 1., 0.);  // make it green
  else if ( overButtonEight ) glColor3f(.75,.75,.75);  // light gray
  else glColor3f(0, 0, 0);  // black
  drawBox(buttonEightPos);

  // draw button nine
  if ( buttonNineIsPressed ) glColor3f(0., 1., 0.);  // make it green
  else if ( overButtonNine ) glColor3f(.75,.75,.75);  // light gray
  else glColor3f(0, 0, 0);  // black
  drawBox(buttonNinePos);

  if(UIBoard[1].getType()==1)
    drawTexture(xTexture, 100, 100, 100, 100);
  if(UIBoard[2].getType()==1)
    drawTexture(xTexture, 200, 100, 100, 100);
  if(UIBoard[3].getType()==1)
    drawTexture(xTexture, 300, 100, 100, 100);
  if(UIBoard[4].getType()==1)
    drawTexture(xTexture, 100, 200, 100, 100);
  if(UIBoard[5].getType()==1)
    drawTexture(xTexture, 200, 200, 100, 100);
  if(UIBoard[6].getType()==1)
    drawTexture(xTexture, 300, 200, 100, 100);
  if(UIBoard[7].getType()==1)
    drawTexture(xTexture, 100, 300, 100, 100);
  if(UIBoard[8].getType()==1)
    drawTexture(xTexture, 200, 300, 100, 100);
  if(UIBoard[9].getType()==1)
    drawTexture(xTexture, 300, 300, 100, 100);

  if(UIBoard[1].getType()==2)
    drawTexture(oTexture, 100, 100, 100, 100);
  if(UIBoard[2].getType()==2)
    drawTexture(oTexture, 200, 100, 100, 100);
  if(UIBoard[3].getType()==2)
    drawTexture(oTexture, 300, 100, 100, 100);
  if(UIBoard[4].getType()==2)
    drawTexture(oTexture, 100, 200, 100, 100);
  if(UIBoard[5].getType()==2)
    drawTexture(oTexture, 200, 200, 100, 100);
  if(UIBoard[6].getType()==2)
    drawTexture(oTexture, 300, 200, 100, 100);
  if(UIBoard[7].getType()==2)
    drawTexture(oTexture, 100, 300, 100, 100);
  if(UIBoard[8].getType()==2)
    drawTexture(oTexture, 200, 300, 100, 100);
  if(UIBoard[9].getType()==2)
    drawTexture(oTexture, 300, 300, 100, 100);

  glColor3f(1,1,1);
  drawBox(lineOnePos);
  drawBox(lineTwoPos);
  drawBox(lineThreePos);
  drawBox(lineFourPos);

  // tell the graphics card that we're done-- go ahead and draw!
  //   (technically, we are switching between two color buffers...)
  glutSwapBuffers();
}

// close the window and finish the program
void exitAll()
{
  int wind = glutGetWindow();
  glutDestroyWindow(wind);
  exit(0);
}

void firstTurnCheck(){
  int check = rand()%2;
  cout<<check;
  if(check==1){
    int bs;
    bs=ai.RandomAI(UIBoard);
    ai.MakeMove(UIBoard, bs);
  }
}

// process keyboard events
void keyboard( unsigned char c, int x, int y )
{
    switch(c) {
      case 'k':
	firstTurnCheck();
      case 'q':
      case 'Q':
      case 27:
        exitAll();
        break;
      default:
        break;
    }
  
    glutPostRedisplay();
}

// the reshape function handles the case where the user changes the size
//   of the window.  We need to fix the coordinate
//   system, so that the drawing area is still the unit square.
void reshape(int w, int h)
{
   glViewport(0, 0, (GLsizei) w, (GLsizei) h);
   WIDTH = w;  HEIGHT = h;
   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();
   glOrtho(0., WIDTH-1, HEIGHT-1, 0., -1.0, 1.0);
}


// the following function tests whether a point at position x,y is inside
//   the rectangle on the screen corresponding to the button
bool onButtonOne(int x, int y)
{
  return x >= buttonOnePos[0]  && y >= buttonOnePos[1] &&
         x <= buttonOnePos[0] + buttonOnePos[2] &&
         y <= buttonOnePos[1] + buttonOnePos[3];
}


bool onButtonTwo(int x, int y)
{
  return x >= buttonTwoPos[0]  && y >= buttonTwoPos[1] &&
         x <= buttonTwoPos[0] + buttonTwoPos[2] &&
         y <= buttonTwoPos[1] + buttonTwoPos[3];
}

bool onButtonThree(int x, int y)
{
  return x >= buttonThreePos[0]  && y >= buttonThreePos[1] &&
         x <= buttonThreePos[0] + buttonThreePos[2] &&
         y <= buttonThreePos[1] + buttonThreePos[3];
}

bool onButtonFour(int x, int y)
{
  return x >= buttonFourPos[0]  && y >= buttonFourPos[1] &&
         x <= buttonFourPos[0] + buttonFourPos[2] &&
         y <= buttonFourPos[1] + buttonFourPos[3];
}

bool onButtonFive(int x, int y)
{
  return x >= buttonFivePos[0]  && y >= buttonFivePos[1] &&
         x <= buttonFivePos[0] + buttonFivePos[2] &&
         y <= buttonFivePos[1] + buttonFivePos[3];
}

bool onButtonSix(int x, int y)
{
  return x >= buttonSixPos[0]  && y >= buttonSixPos[1] &&
         x <= buttonSixPos[0] + buttonSixPos[2] &&
         y <= buttonSixPos[1] + buttonSixPos[3];
}

bool onButtonSeven(int x, int y)
{
  return x >= buttonSevenPos[0]  && y >= buttonSevenPos[1] &&
         x <= buttonSevenPos[0] + buttonSevenPos[2] &&
         y <= buttonSevenPos[1] + buttonSevenPos[3];
}

bool onButtonEight(int x, int y)
{
  return x >= buttonEightPos[0]  && y >= buttonEightPos[1] &&
         x <= buttonEightPos[0] + buttonEightPos[2] &&
         y <= buttonEightPos[1] + buttonEightPos[3];
}

bool onButtonNine(int x, int y)
{
  return x >= buttonNinePos[0]  && y >= buttonNinePos[1] &&
         x <= buttonNinePos[0] + buttonNinePos[2] &&
         y <= buttonNinePos[1] + buttonNinePos[3];
}


// the mouse function is called when a mouse button is pressed down or released
void mouse(int mouseButton, int state, int x, int y)
{
  if ( GLUT_LEFT_BUTTON == mouseButton ) {
    if ( GLUT_DOWN == state ) {
      // the user just pressed down on the mouse-- do something
      if ( onButtonOne(x,y) ) 
        buttonOneIsPressed = true;
      else buttonOneIsPressed = false;
      if ( onButtonTwo(x,y) )
        buttonTwoIsPressed = true;
      else buttonTwoIsPressed = false;
      if ( onButtonThree(x,y) )
        buttonThreeIsPressed = true;
      else buttonThreeIsPressed = false;
      if ( onButtonFour(x,y) )
        buttonFourIsPressed = true;
      else buttonFourIsPressed = false;
      if ( onButtonFive(x,y) )
        buttonFiveIsPressed = true;
      else buttonFiveIsPressed = false;
      if ( onButtonSix(x,y) )
        buttonSixIsPressed = true;
      else buttonSixIsPressed = false;
      if ( onButtonSeven(x,y) )
        buttonSevenIsPressed = true;
      else buttonSevenIsPressed = false;
      if ( onButtonEight(x,y) )
        buttonEightIsPressed = true;
      else buttonEightIsPressed = false;
      if ( onButtonNine(x,y) )
        buttonNineIsPressed = true;
      else buttonNineIsPressed = false;
    } 
      else {
      // the user just let go the mouse-- do something
      if ( onButtonOne(x,y) && buttonOneIsPressed ){
	UIBoard[1].setType(1);
        cout << "Button one press." << endl;
	win=UIBoard.winCheck();
	int bs;
	bs=ai.RandomAI(UIBoard);
        ai.MakeMove(UIBoard, bs);
      }
      buttonOneIsPressed = false;
      if ( onButtonTwo(x,y) && buttonTwoIsPressed ){
	cout << "Button two press." << endl;
	UIBoard[2].setType(1);
	win=UIBoard.winCheck();
	int bs;
	bs=ai.RandomAI(UIBoard);
        ai.MakeMove(UIBoard, bs);
      }
      buttonTwoIsPressed = false;
      if ( onButtonThree(x,y) && buttonThreeIsPressed ){
	cout << "Button three press." << endl;
	UIBoard[3].setType(1);
	win=UIBoard.winCheck();
	int bs;
	bs=ai.RandomAI(UIBoard);
        ai.MakeMove(UIBoard, bs);
      }
      buttonThreeIsPressed = false;
      if ( onButtonFour(x,y) && buttonFourIsPressed ){
	cout << "Button four press." << endl;
	UIBoard[4].setType(1);
	win=UIBoard.winCheck();
	int bs;
	bs=ai.RandomAI(UIBoard);
        ai.MakeMove(UIBoard, bs);
      }
      buttonFourIsPressed = false;
      if ( onButtonFive(x,y) && buttonFiveIsPressed ){
	cout << "Button five press." << endl;
	UIBoard[5].setType(1);
	win=UIBoard.winCheck();
	int bs;
	bs=ai.RandomAI(UIBoard);
        ai.MakeMove(UIBoard, bs);
      }
      buttonFiveIsPressed = false;
      if ( onButtonSix(x,y) && buttonSixIsPressed ){
	cout << "Button six press." << endl;
	UIBoard[6].setType(1);
	win=UIBoard.winCheck();
	int bs;
	bs=ai.RandomAI(UIBoard);
        ai.MakeMove(UIBoard, bs);
      }
      buttonSixIsPressed = false;
      if ( onButtonSeven(x,y) && buttonSevenIsPressed ){
	cout << "Button seven press." << endl;
	UIBoard[7].setType(1);
	win=UIBoard.winCheck();
	int bs;
	bs=ai.RandomAI(UIBoard);
        ai.MakeMove(UIBoard, bs);
      }
      buttonSevenIsPressed = false;
      if ( onButtonEight(x,y) && buttonEightIsPressed ){
	cout << "Button eight press." << endl;
	UIBoard[8].setType(1);
	win=UIBoard.winCheck();
	int bs;
	bs=ai.RandomAI(UIBoard);
        ai.MakeMove(UIBoard, bs);
      }
      buttonEightIsPressed = false;
      if ( onButtonNine(x,y) && buttonNineIsPressed ){
	cout << "Button nine press." << endl;
	UIBoard[9].setType(1);
	win=UIBoard.winCheck();
	int bs;
	bs=ai.RandomAI(UIBoard);
        ai.MakeMove(UIBoard, bs);
      }
      buttonNineIsPressed = false;

    }
  } else if ( GLUT_RIGHT_BUTTON == mouseButton )
  glutPostRedisplay();
}

// the mouse_motion function is called when the mouse is being dragged,
//   and gives the current location of the mouse
void mouse_motion(int x,int y)
{
    { if ( onButtonOne(x,y) ) overButtonOne = true;
    else overButtonOne = false;
    if ( onButtonTwo(x,y) ) overButtonTwo = true;
    else overButtonTwo = false;
    if ( onButtonThree(x,y) ) overButtonThree = true;
    else overButtonThree = false;
    if ( onButtonFour(x,y) ) overButtonFour = true;
    else overButtonFour = false;
    if ( onButtonFive(x,y) ) overButtonFive = true;
    else overButtonFive = false;
    if ( onButtonSix(x,y) ) overButtonSix = true;
    else overButtonSix = false;
    if ( onButtonSeven(x,y) ) overButtonSeven = true;
    else overButtonSeven = false;
    if ( onButtonEight(x,y) ) overButtonEight = true;
    else overButtonEight = false;
    if ( onButtonNine(x,y) ) overButtonNine = true;
    else overButtonNine = false;}

  glutPostRedisplay();
}

// the init function sets up the graphics card to draw properly
void init(void)
{
  // clear the window to black
  glClearColor(0.0, 0.0, 0.0, 1.0);
  glClear(GL_COLOR_BUFFER_BIT);

  // set up the coordinate system:  number of pixels along x and y
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  glOrtho(0., WIDTH-1, HEIGHT-1, 0., -1.0, 1.0);

  // welcome message
  cout << "Welcome to " << programName << ".  Try pressing the button, moving the slider," << endl;
  cout << " or typing in the text box." << endl;
}


// init_gl_window is the function that starts the ball rolling, in
//  terms of getting everything set up and passing control over to the
//  glut library for event handling.  It needs to tell the glut library
//  about all the essential functions:  what function to call if the
//  window changes shape, what to do to redraw, handle the keyboard,
//  etc.
void init_gl_window()
{
  char *argv[] = { programName };
  int argc = sizeof(argv) / sizeof(argv[0]);
  glutInit(&argc, argv);
  glutInitDisplayMode( GLUT_RGBA | GLUT_DOUBLE );
  glutInitWindowSize(WIDTH,HEIGHT);
  glutInitWindowPosition(100,100);
  glutCreateWindow(programName);
  init();

  xTexture = loadTexture("x.pam");
  oTexture = loadTexture("o.pam");

  glutDisplayFunc(drawWindow);
  glutReshapeFunc(reshape);
  glutKeyboardFunc(keyboard);
  glutMouseFunc(mouse);
  glutMotionFunc(mouse_motion);
  glutPassiveMotionFunc(mouse_motion);
  glutMainLoop();
}

int main()
{
  init_gl_window();
}
