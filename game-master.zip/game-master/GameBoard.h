#ifndef _GAMEBOARD_H_
#define _GAMEBOARD_H_
#include <iostream>
#include "BoardSpot.h"


using namespace std;

class GameBoard{
 protected:
  int size;
 public:
  BoardSpot **BoardSpotArray;
  GameBoard(int a);
  GameBoard();
  GameBoard(const GameBoard& gb);
  ~GameBoard();
  void display();
  void playerMove();
  int winCheck();
  int getSize() {return size;}
  void copy(GameBoard* c);
  BoardSpot& operator[](int);
};

#endif
