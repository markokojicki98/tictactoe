#include<iostream>
#include"GameBoard.h"
using namespace std;

GameBoard::GameBoard(int a){
  size=a;
  BoardSpotArray = new BoardSpot*[size];
  for(int i = 1; i<size+1; i++){
    BoardSpotArray[i] = new BoardSpot(i,0);
  }
}

GameBoard::GameBoard(){
  size=10;
  BoardSpotArray = new BoardSpot*[10];
  for(int i = 1; i<11; i++){
    BoardSpotArray[i] = new BoardSpot(i,0);
  }
}

GameBoard::GameBoard(const GameBoard& gb){
  for(int i = 1; i<size+1; i++){
    BoardSpotArray[i] = new BoardSpot(gb.BoardSpotArray[i]->place,
                                      gb.BoardSpotArray[i]->type);

  }
}

GameBoard::~GameBoard(){
  delete [] BoardSpotArray;
}


int GameBoard::winCheck(){
  if(BoardSpotArray[1]->type==1){
    if(BoardSpotArray[2]->type==1){
      if(BoardSpotArray[3]->type==1)
        return 1;
      }
    if(BoardSpotArray[4]->type==1){
      if(BoardSpotArray[7]->type==1)
        return 1;
    }
    if(BoardSpotArray[5]->type==1){
      if(BoardSpotArray[9]->type==1)
        return 1;
    }
  }

  if(BoardSpotArray[2]->type==1){
    if(BoardSpotArray[5]->type==1){
      if(BoardSpotArray[8]->type==1)
        return 1;
    }
  }

  if(BoardSpotArray[3]->type==1){
    if(BoardSpotArray[5]->type==1){
      if(BoardSpotArray[7]->type==1)
    return 1;
    }
    if(BoardSpotArray[6]->type==1){
        if(BoardSpotArray[9]->type==1)
      return 1;
    }
  }
  if(BoardSpotArray[4]->type==1){
    if(BoardSpotArray[5]->type==1){
      if(BoardSpotArray[6]->type==1)
        return 1;
    }
  }

  if(BoardSpotArray[7]->type==1){
    if(BoardSpotArray[8]->type==1){
      if(BoardSpotArray[9]->type==1)
    return 1;
    }
  }
  ///////////////////AI/////
 if(BoardSpotArray[1]->type==2){
    if(BoardSpotArray[2]->type==2){
      if(BoardSpotArray[3]->type==2)
        return 2;
      }
    if(BoardSpotArray[4]->type==2){
      if(BoardSpotArray[7]->type==2)
        return 2;
    }
    if(BoardSpotArray[5]->type==2){
      if(BoardSpotArray[9]->type==2)
        return 2;
    }
  }

  if(BoardSpotArray[2]->type==2){
    if(BoardSpotArray[5]->type==2){
      if(BoardSpotArray[8]->type==2)
        return 2;
    }
  }

  if(BoardSpotArray[3]->type==2){
    if(BoardSpotArray[5]->type==2){
      if(BoardSpotArray[7]->type==2)
    return 2;
    }
    if(BoardSpotArray[6]->type==2){
        if(BoardSpotArray[9]->type==2)
      return 2;
    }
  }
  if(BoardSpotArray[4]->type==2){
    if(BoardSpotArray[5]->type==2){
      if(BoardSpotArray[6]->type==2)
        return 2;
    }
  }

  if(BoardSpotArray[7]->type==2){
    if(BoardSpotArray[8]->type==2){
      if(BoardSpotArray[9]->type==2)
    return 2;
    }
  }



  else
    return 0;
}

void GameBoard::copy(GameBoard* c){
  for (int i = 0; BoardSpotArray[i] != '\0'; i++)
    c->BoardSpotArray[i] = BoardSpotArray[i];
}

BoardSpot& GameBoard::operator[](int i){
  if(i>0 && i<size){
    return *BoardSpotArray[i];
  }
}
