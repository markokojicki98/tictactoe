#include<iostream>
#include"AI.h"
#include<cstdlib>
using namespace std;

AI::AI(){
  level = 1;
}

AI::AI(int lvl){
  level = lvl;
}

int AI::EasyAI(GameBoard & g){
  int l;
  l=g.getSize();
  for (int i = 1; i < l+1; i++){
     if (g.BoardSpotArray[i]->getType() == 0)
      return i;
  }
}

int AI::RandomAI(GameBoard & g){
  int m;
  for (int i = 1; i<10; i++){
    m=(rand()%9)+1;
    if(g.BoardSpotArray[m]->getType() == 0)
      return m;
  }
}

int AI::MiniMax(GameBoard& g, int d, bool isPlayer, int maxb, int minb){
  int l;
  l=g.getSize();  
  if (g.winCheck() == 1){
    return 100 - d; 
  }
 
    //if ai won
  else if (g.winCheck() == 2){
   return -100 - d; 
  }  

    //no winner
  else if (g.fullBoard()) {return 0;}

    if (isPlayer)
    {
        int maxbest = maxb;
	int minbest = minb;
	//if (d == 0)
	//     best = -500;
        for (int i = 1; i<l+1 ; i++){
	  // Check if cell is empty
	  if (g.BoardSpotArray[i]->type == 0){
	    g.BoardSpotArray[i]->setType(1);
	    int minimax  = max(minimax, MiniMax(g, d+1, !isPlayer, maxbest, minbest));
	    //if minimax val one iteration deeper is more then best, best = mini
	    //max val
	    if (maxbest < minimax)
	      maxbest = minimax;
	    g.BoardSpotArray[i]->setType(0);
	  }
        }
        return maxbest;
    }
 
    //if ai move
    else
    {
      int minbest = minb;
      int maxbest = maxb;
      for (int i = 1; i<l+1 ; i++){
	// Check if cell is empty
	if (g.BoardSpotArray[i]->type == 0){
	  g.BoardSpotArray[i]->setType(2);
	  int minimax  = min(minimax, MiniMax(g, d+1, !isPlayer, maxbest, minbest));
	  g.BoardSpotArray[i]->setType(0);
	  if (minbest > minimax)
	    minbest = minimax;
	}
      }
      return minbest;
    }
}

int AI::BestMove(GameBoard& g){
  int l;
  l=g.getSize();
  int maxval = 1000;
  int bestmove;
 
    //calls minimax for all empty spots, saves best scoring moves
    for (int i = 1; i<l+1 ; i++){
      if (g.BoardSpotArray[i]->type == 0)
	{
	  g.BoardSpotArray[i]->setType(2);
	  int moveval = MiniMax(g, 0, false, -500, 500);	  
	  g.BoardSpotArray[i]->setType(0);
	  if (moveval < maxval)
	    {
	      bestmove = i;
	      maxval = moveval;
	    }
	}
    }

    return bestmove;

}

void AI::MakeMove(GameBoard & g, int loc){
  g.BoardSpotArray[loc]->setType(2);
}
